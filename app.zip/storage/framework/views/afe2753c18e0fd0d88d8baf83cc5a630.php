<?php $__env->startSection('title'); ?>
    Service Single
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    services-pet-hotel
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\aioli\Herd\aio_pets\resources\views/pages/services-pet-hotel.blade.php ENDPATH**/ ?>