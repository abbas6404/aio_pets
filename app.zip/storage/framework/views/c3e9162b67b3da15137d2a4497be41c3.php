    <div class="crumbs">
        <span class="first-item">
            <a href="<?php echo e(url('/')); ?>">Homepage</a>
        </span>
        <span class="last-item">
            <?php if(Request::is('about')): ?>
                About
            <?php elseif(Request::is('contact')): ?>
                Contact
            <?php elseif(Request::is('gallery')): ?>
                Gallery
            <?php elseif(Request::is('adoption')): ?>
                Adoption
            <?php elseif(Request::is('our-services')): ?>
                Our Services
            <?php elseif(Request::is('services-pet-hotel')): ?>
                Service Single
            <?php elseif(Request::is('blog') && !Request::is('blog/*')): ?>
                Blog
            <?php elseif(Request::is('blog/*')): ?>
                Blog Single
            <?php else: ?>
                <?php echo e(ucfirst(str_replace('-', ' ', Request::segment(1)))); ?>

            <?php endif; ?>
        </span>
    </div>
<?php /**PATH C:\Users\aioli\Herd\aio_pets\resources\views/components/crumbs.blade.php ENDPATH**/ ?>