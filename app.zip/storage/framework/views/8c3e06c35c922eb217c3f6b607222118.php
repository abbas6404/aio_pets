<nav class="petz-breadcrumb flw" style="background-image: url(../wp-content/uploads/2017/04/jumbotron.jpg)">
        <div class="container">
            <div class="bread flw" itemscope itemtype="http://schema.org/WebPage">
                <h1 class="page-title" itemprop="name">
                    <?php if (! empty(trim($__env->yieldContent('title')))): ?>
                        <?php echo $__env->yieldContent('title'); ?>
                    <?php else: ?>
                        <?php if(Request::is('about')): ?>
                            About
                        <?php elseif(Request::is('contact')): ?>
                            Contact
                        <?php elseif(Request::is('gallery')): ?>
                            Gallery
                        <?php elseif(Request::is('adoption')): ?>
                            Adoption
                        <?php elseif(Request::is('our-services')): ?>
                            Our Services
                        <?php elseif(Request::is('services-pet-hotel')): ?>
                            Service Single
                        <?php elseif(Request::is('blog') && !Request::is('blog/*')): ?>
                            Blog
                        <?php elseif(Request::is('blog/*')): ?>
                            Blog Single
                        <?php else: ?>
                            <?php echo e(ucfirst(str_replace('-', ' ', Request::segment(1)))); ?>

                        <?php endif; ?>
                    <?php endif; ?>
                </h1>
            </div>
        </div>
    </nav>
<?php /**PATH C:\Users\aioli\Herd\aio_pets\resources\views/components/nav.blade.php ENDPATH**/ ?>