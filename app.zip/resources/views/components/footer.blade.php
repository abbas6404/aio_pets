 <footer class="petz-footer flw">
        <div class="container footer-widget">
            <div class="col-md-4">
                <aside id="text-3" class="widget widget_text">
                    <div class="textwidget">
                        <div class="text-center">
                            <a href="../index.html"><img src="../wp-content/themes/petz/images/logo.png"
                                    alt="Logo image" /></a>
                        </div>
                    </div>
                </aside>
            </div>
            <div class="col-md-4">
                <aside id="text-4" class="widget widget_text">
                    <div class="textwidget">
                        <ul class="footer-info text-center">
                            <li><i class="fa fa-phone"></i>(000) 000-000</li>
                            <li>
                                <i class="fa fa-envelope"></i>Email:
                                <a href="../cdn-cgi/l/email-protection.html#532a3c262113363e323a3f7d303c3e"><span
                                        class="__cf_email__"
                                        data-cfemail="b4c7ddc0d1f4d1d9d5ddd89ad7dbd9">[email&#160;protected]</span></a>
                            </li>
                            <li>
                                <i class="fa fa-map-marker"></i>123 Anywhere Street,London,LO4
                                6ON
                            </li>
                        </ul>
                    </div>
                </aside>
            </div>
            <div class="col-md-4">
                <aside id="text-5" class="widget widget_text">
                    <h5 class="footer-widget-title">FOLLOW US</h5>
                    <div class="textwidget">
                        <div class="social-media text-center">
                            <a href="https://www.twitter.com/haintheme"></a>
                            <a href="https://www.facebook.com/haintheme"></a>
                            <a href="https://plus.google.com/haintheme"></a>
                            <a href="https://instagram.com/haintheme"></a>
                        </div>
                    </div>
                </aside>
            </div>
        </div>

        <div class="credits container text-center">
            Petz by
            <a href="https://themeforest.net/user/haintheme" target="_blank">Haintheme</a>
            &copy; 2017. All Rights Reserved.
        </div>

        <div class="page-scroll hidden-sm hidden-xs">
            <button class="back-to-top"><i class="fa fa-angle-up"></i></button>
        </div>
    </footer>
