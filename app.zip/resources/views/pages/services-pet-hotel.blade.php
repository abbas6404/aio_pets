@extends('layouts.app')
@section('title')
    Service Single
@endsection
@section('content')
    services-pet-hotel
@endsection
